# SSD MID-SEM EVALUATION
- Group: **SSD-29**
- Link: https://www.youtube.com/watch?v=hlbs2I5x93k&feature=youtu.be