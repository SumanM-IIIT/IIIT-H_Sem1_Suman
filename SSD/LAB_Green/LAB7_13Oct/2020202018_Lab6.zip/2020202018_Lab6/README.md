# SSD LAB ACTIVITY - 6

### Q1:
- Created a folder **Q1**. Inside it, there is the required **in_bestseller.py** file.
- Inside **Q1**, there is a folder named **output** inside which the csv file **in_book.csv** is created after running the program.
- An exception of **URL fetching** using **urllib** is handled in the code.

### Q2:
- The input string is taken from the user.
- Imported **string** package for using **string.ascii_lowercase**

### Q3:
- Taking comma separated input string of names from user.
- Used **Lambda function** for returning the length of a name.

### Q4:
- Taking comma separated input string of binary numbers from user.
- Printing the output in comma separated sequence.
