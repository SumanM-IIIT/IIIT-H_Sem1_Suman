ch = input();
if ch in ['a', 'e', 'i', 'o', 'u', 'A', 'E', 'I', 'O', 'U']:
	print("True");
else:
	print("False");