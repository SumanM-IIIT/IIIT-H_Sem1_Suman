x,y = input().split();
if int(x) > int(y):
	print(x);
else:
	print(y);