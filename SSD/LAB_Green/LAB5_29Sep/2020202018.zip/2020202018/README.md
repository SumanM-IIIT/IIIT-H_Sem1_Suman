# SSD LAB ACTIVITY - 5

### Q1:
- Taken **two space-separated inputs** in a single line using **split()**.
- Type casted the two inputs into **int** while checking the largest value.

### Q2:
- Taken a **list of vowels** (both uppercase and lowercase) and checking the input in that list.

### Q3:
- Firstly removed blank spaces using **replace(" ","")** and then used **","** delimiter to split the user input using **split(",")**.
- Used **map()** and passed the arguments **len** method with the **word list** to store the lengths of each word in the resultant list. 

### Q4:
- used **[::-1]** to reverse the string.
