# SSD LAB ACTIVITY - 4
### Q1.a.
  - Created the list using HTML, Jquery and CSS. Used **onmouseover** to hover over a button to show a div containing list items where each list is a hyperlink.
  - When we click on any other part of the window, the list is closed. This is implemented in JQuery using **window.onclick** function.

### Q1.b.
- Used **css()** function of JQuery to change the page background on button click using **click()** function.

### Q1.c.
- Used **match()** function of JQuery for RegEx matching to check if the user has pressed "3" or not. If yes, then an alert box is popped up using **alert()**.

### Q1.d.
- Used **fadeOut()** and **fadeIn()** functions of JQuery to change the visibility of text from *completely visible* to *hidden* and vice-versa.  
- Did these two fading operations at certain time intervals using **setInterval()** to produce the blinking effect.


## EXTRA:
- Used a bit of external **CSS** for formatting the buttons and divs. 