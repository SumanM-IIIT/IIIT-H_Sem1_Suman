#!/bin/bash
clear
cd /usr/local/lib			#1. Absolute path
cd -					#2. Switch to previous working directory
cd ../../../../../../../usr/src/	#3. Used the relative path  w.r.t. my system. It may vary from system to system.
cd ~					#4. User's Home Directory
mkdir -p ~/Documents/LabActivity1	#5. Create directory
cd ~/Documents/LabActivity1		#6. Enter directory


