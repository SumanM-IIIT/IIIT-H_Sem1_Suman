1. For each command, specific comments are given in the .sh files itself.
2. Some commands are either independent or relative to my system. So, they may or may not work by running the whole script at once. But they all will run individually for sure.
3. This 2nd submission is just for editing and re--uploading the Readme.txt file.